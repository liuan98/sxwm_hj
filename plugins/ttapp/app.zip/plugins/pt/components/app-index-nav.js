(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/pt/components/app-index-nav"],{"387c":function(t,n,e){"use strict";e.r(n);var u=e("bd45"),a=e.n(u);for(var c in u)"default"!==c&&function(t){e.d(n,t,function(){return u[t]})}(c);n["default"]=a.a},4300:function(t,n,e){"use strict";var u=function(){var t=this,n=t.$createElement;t._self._c},a=[];e.d(n,"a",function(){return u}),e.d(n,"b",function(){return a})},7136:function(t,n,e){"use strict";e.r(n);var u=e("4300"),a=e("387c");for(var c in a)"default"!==c&&function(t){e.d(n,t,function(){return a[t]})}(c);e("e1cb");var r=e("2877"),i=Object(r["a"])(a["default"],u["a"],u["b"],!1,null,"f0055ac4",null);n["default"]=i.exports},bd45:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"app-index-nav",props:{list:{type:Array,default:function(){return[]}},cat_id:Number},data:function(){return{activeIndex:0}},methods:{active:function(t){this.$emit("click",t)}}};n.default=u},e1cb:function(t,n,e){"use strict";var u=e("e7ee"),a=e.n(u);a.a},e7ee:function(t,n,e){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/pt/components/app-index-nav-create-component',
    {
        'plugins/pt/components/app-index-nav-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("7136"))
        })
    },
    [['plugins/pt/components/app-index-nav-create-component']]
]);                
