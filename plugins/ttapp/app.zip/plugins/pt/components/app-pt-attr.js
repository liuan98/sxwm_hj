(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/pt/components/app-pt-attr"],{"27cd":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"app-pt-attr",props:{pintuan_groups:{type:Array,default:function(){return[]}},selectGroupAttrId:String},data:function(){return{}},methods:{active:function(t){this.$emit("click",t)}}};n.default=u},3556:function(t,n,e){"use strict";e.r(n);var u=e("92e7"),r=e("6569");for(var a in r)"default"!==a&&function(t){e.d(n,t,function(){return r[t]})}(a);e("d438");var c=e("2877"),i=Object(c["a"])(r["default"],u["a"],u["b"],!1,null,"7ab2b2c7",null);n["default"]=i.exports},6569:function(t,n,e){"use strict";e.r(n);var u=e("27cd"),r=e.n(u);for(var a in u)"default"!==a&&function(t){e.d(n,t,function(){return u[t]})}(a);n["default"]=r.a},"92e7":function(t,n,e){"use strict";var u=function(){var t=this,n=t.$createElement;t._self._c},r=[];e.d(n,"a",function(){return u}),e.d(n,"b",function(){return r})},c970:function(t,n,e){},d438:function(t,n,e){"use strict";var u=e("c970"),r=e.n(u);r.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/pt/components/app-pt-attr-create-component',
    {
        'plugins/pt/components/app-pt-attr-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("3556"))
        })
    },
    [['plugins/pt/components/app-pt-attr-create-component']]
]);                
