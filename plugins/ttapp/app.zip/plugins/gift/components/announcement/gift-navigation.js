(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/gift/components/announcement/gift-navigation"],{"022c":function(n,t,e){"use strict";e.r(t);var o=e("bfcf"),a=e.n(o);for(var u in o)"default"!==u&&function(n){e.d(t,n,function(){return o[n]})}(u);t["default"]=a.a},6696:function(n,t,e){"use strict";var o=function(){var n=this,t=n.$createElement;n._self._c},a=[];e.d(t,"a",function(){return o}),e.d(t,"b",function(){return a})},"6a21":function(n,t,e){},aaa8:function(n,t,e){"use strict";e.r(t);var o=e("6696"),a=e("022c");for(var u in a)"default"!==u&&function(n){e.d(t,n,function(){return a[n]})}(u);e("f1790");var r=e("2877"),c=Object(r["a"])(a["default"],o["a"],o["b"],!1,null,"6183fc10",null);t["default"]=c.exports},bfcf:function(n,t,e){"use strict";(function(n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o=function(){return e.e("components/basic-component/app-iphone-x/app-iphone-x").then(e.bind(null,"7598"))},a={name:"gift-navigation",props:["theme","botHeight","navBool"],data:function(){return{tab_route:"",load_success:!1}},created:function(){var n=getCurrentPages();this.tab_route=n[n.length-1].route},methods:{routeGo:function(t){n.redirectTo({url:t})}},components:{"app-iphone-x":o}};t.default=a}).call(this,e("f266")["default"])},f1790:function(n,t,e){"use strict";var o=e("6a21"),a=e.n(o);a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/gift/components/announcement/gift-navigation-create-component',
    {
        'plugins/gift/components/announcement/gift-navigation-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("aaa8"))
        })
    },
    [['plugins/gift/components/announcement/gift-navigation-create-component']]
]);                
