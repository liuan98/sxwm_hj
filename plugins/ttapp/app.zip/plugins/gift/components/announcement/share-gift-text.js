(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/gift/components/announcement/share-gift-text"],{"2ae9":function(n,t,e){"use strict";var a=function(){var n=this,t=n.$createElement;n._self._c},u=[];e.d(t,"a",function(){return a}),e.d(t,"b",function(){return u})},"2d6b":function(n,t,e){"use strict";var a=e("7bda"),u=e.n(a);u.a},"7bda":function(n,t,e){},9827:function(n,t,e){"use strict";e.r(t);var a=e("2ae9"),u=e("fd8b");for(var r in u)"default"!==r&&function(n){e.d(t,n,function(){return u[n]})}(r);e("2d6b");var f=e("2877"),i=Object(f["a"])(u["default"],a["a"],a["b"],!1,null,"a3127262",null);t["default"]=i.exports},e2de:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a={name:"ready-send",props:["big","small"]};t.default=a},fd8b:function(n,t,e){"use strict";e.r(t);var a=e("e2de"),u=e.n(a);for(var r in a)"default"!==r&&function(n){e.d(t,n,function(){return a[n]})}(r);t["default"]=u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/gift/components/announcement/share-gift-text-create-component',
    {
        'plugins/gift/components/announcement/share-gift-text-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("9827"))
        })
    },
    [['plugins/gift/components/announcement/share-gift-text-create-component']]
]);                
