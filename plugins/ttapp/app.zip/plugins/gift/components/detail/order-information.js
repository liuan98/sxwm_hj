(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/gift/components/detail/order-information"],{"05ea":function(n,t,e){},9193:function(n,t,e){"use strict";e.r(t);var a=e("b208"),r=e.n(a);for(var u in a)"default"!==u&&function(n){e.d(t,n,function(){return a[n]})}(u);t["default"]=r.a},a442:function(n,t,e){"use strict";var a=e("05ea"),r=e.n(a);r.a},b208:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a={name:"order-information",props:["status","order_no","type","pay_time","open_time","open_num"]};t.default=a},ba35:function(n,t,e){"use strict";var a=function(){var n=this,t=n.$createElement;n._self._c},r=[];e.d(t,"a",function(){return a}),e.d(t,"b",function(){return r})},e1db:function(n,t,e){"use strict";e.r(t);var a=e("ba35"),r=e("9193");for(var u in r)"default"!==u&&function(n){e.d(t,n,function(){return r[n]})}(u);e("a442");var o=e("2877"),i=Object(o["a"])(r["default"],a["a"],a["b"],!1,null,"cbf656ac",null);t["default"]=i.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/gift/components/detail/order-information-create-component',
    {
        'plugins/gift/components/detail/order-information-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("e1db"))
        })
    },
    [['plugins/gift/components/detail/order-information-create-component']]
]);                
