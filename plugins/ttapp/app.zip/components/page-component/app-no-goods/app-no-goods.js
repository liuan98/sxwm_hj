(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-no-goods/app-no-goods"],{"3da24":function(n,t,e){"use strict";e.r(t);var u=e("4742"),a=e.n(u);for(var o in u)"default"!==o&&function(n){e.d(t,n,function(){return u[n]})}(o);t["default"]=a.a},4742:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={name:"app-no-goods",props:{background:{type:String,default:function(){return"#ffffff"}},title:{type:String,default:function(){return"没有任何商品哦~"}},is_image:{type:Number,default:function(){return 0}}}};t.default=u},7785:function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},a=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return a})},"7aab":function(n,t,e){"use strict";var u=e("8776"),a=e.n(u);a.a},8112:function(n,t,e){"use strict";e.r(t);var u=e("7785"),a=e("3da24");for(var o in a)"default"!==o&&function(n){e.d(t,n,function(){return a[n]})}(o);e("7aab");var r=e("2877"),f=Object(r["a"])(a["default"],u["a"],u["b"],!1,null,"30c98249",null);t["default"]=f.exports},8776:function(n,t,e){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-no-goods/app-no-goods-create-component',
    {
        'components/page-component/app-no-goods/app-no-goods-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("8112"))
        })
    },
    [['components/page-component/app-no-goods/app-no-goods-create-component']]
]);                
