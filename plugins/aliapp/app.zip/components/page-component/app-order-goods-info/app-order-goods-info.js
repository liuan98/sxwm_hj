;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-order-goods-info/app-order-goods-info"],{1602:function(n,t,e){"use strict";e.r(t);var o=e("a370"),a=e("9c56");for(var r in a)"default"!==r&&function(n){e.d(t,n,function(){return a[n]})}(r);e("2a58");var u=e("2877"),c=Object(u["a"])(a["default"],o["a"],o["b"],!1,null,"75274a68",null);t["default"]=c.exports},"2a58":function(n,t,e){"use strict";var o=e("c8c2"),a=e.n(o);a.a},"5a2d":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o={name:"app-order-goods-info",data:function(){return{}},props:{goods:{type:Object,default:{}}}};t.default=o},"9c56":function(n,t,e){"use strict";e.r(t);var o=e("5a2d"),a=e.n(o);for(var r in o)"default"!==r&&function(n){e.d(t,n,function(){return o[n]})}(r);t["default"]=a.a},a370:function(n,t,e){"use strict";var o=function(){var n=this,t=n.$createElement;n._self._c},a=[];e.d(t,"a",function(){return o}),e.d(t,"b",function(){return a})},c8c2:function(n,t,e){}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-order-goods-info/app-order-goods-info-create-component',
    {
        'components/page-component/app-order-goods-info/app-order-goods-info-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("1602"))
        })
    },
    [['components/page-component/app-order-goods-info/app-order-goods-info-create-component']]
]);                
