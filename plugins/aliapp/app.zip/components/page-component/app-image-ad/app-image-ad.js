;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-image-ad/app-image-ad"],{"0065":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"app-image-ad",props:{h:{type:Number,default:function(){return 1}},height:{default:function(){return"auto"}},hotspot:{type:Array,default:function(){return[]}},list:{type:Array,default:function(){return[]}},space:{type:Number,default:function(){return 0}},imageStyle:{type:Number,default:function(){return 2}},w:{type:Number,default:function(){return 25}}}};e.default=u},"214f":function(t,e,n){},"605d":function(t,e,n){"use strict";n.r(e);var u=n("b3dc"),r=n("d2f0");for(var a in r)"default"!==a&&function(t){n.d(e,t,function(){return r[t]})}(a);n("7b14");var f=n("2877"),c=Object(f["a"])(r["default"],u["a"],u["b"],!1,null,"1221e89c",null);e["default"]=c.exports},"7b14":function(t,e,n){"use strict";var u=n("214f"),r=n.n(u);r.a},b3dc:function(t,e,n){"use strict";var u=function(){var t=this,e=t.$createElement;t._self._c},r=[];n.d(e,"a",function(){return u}),n.d(e,"b",function(){return r})},d2f0:function(t,e,n){"use strict";n.r(e);var u=n("0065"),r=n.n(u);for(var a in u)"default"!==a&&function(t){n.d(e,t,function(){return u[t]})}(a);e["default"]=r.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-image-ad/app-image-ad-create-component',
    {
        'components/page-component/app-image-ad/app-image-ad-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("605d"))
        })
    },
    [['components/page-component/app-image-ad/app-image-ad-create-component']]
]);                
