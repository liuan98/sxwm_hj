;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-order-express/app-order-express"],{2338:function(e,n,t){"use strict";t.r(n);var r=t("31d8"),u=t("6e92");for(var a in u)"default"!==a&&function(e){t.d(n,e,function(){return u[e]})}(a);t("95b8");var o=t("2877"),c=Object(o["a"])(u["default"],r["a"],r["b"],!1,null,"14e8b3d4",null);n["default"]=c.exports},"31d8":function(e,n,t){"use strict";var r=function(){var e=this,n=e.$createElement;e._self._c},u=[];t.d(n,"a",function(){return r}),t.d(n,"b",function(){return u})},"6e92":function(e,n,t){"use strict";t.r(n);var r=t("caf5"),u=t.n(r);for(var a in r)"default"!==a&&function(e){t.d(n,e,function(){return r[e]})}(a);n["default"]=u.a},"7e95":function(e,n,t){},"95b8":function(e,n,t){"use strict";var r=t("7e95"),u=t.n(r);u.a},caf5:function(e,n,t){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"app-order-express",data:function(){return{}},props:{express:{type:String,value:""},express_no:{type:String,value:""},pageUrl:{type:String,value:""}}};n.default=r}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-order-express/app-order-express-create-component',
    {
        'components/page-component/app-order-express/app-order-express-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("2338"))
        })
    },
    [['components/page-component/app-order-express/app-order-express-create-component']]
]);                
