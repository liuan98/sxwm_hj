;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/book/components/app-store"],{"0f26":function(t,n,e){"use strict";var u=e("fbfa"),r=e.n(u);r.a},"11db":function(t,n,e){"use strict";e.r(n);var u=e("5bfb"),r=e.n(u);for(var f in u)"default"!==f&&function(t){e.d(n,t,function(){return u[t]})}(f);n["default"]=r.a},"5bfb":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"app-store",props:{borderStyle:{type:Boolean,default:function(){return!0}},icon:{type:Boolean,default:function(){return!0}},storeNum:{type:Number,default:function(){return 0}},business_hours:{type:String,default:function(){return""}},address:{type:String,default:function(){return""}},name:{type:String,default:function(){return""}},store_id:{type:String,default:function(){return""}},title:{type:Boolean,default:function(){return!0}},goods_id:{type:String,default:function(){return""}}}};n.default=u},c0cf:function(t,n,e){"use strict";var u=function(){var t=this,n=t.$createElement;t._self._c},r=[];e.d(n,"a",function(){return u}),e.d(n,"b",function(){return r})},f09e:function(t,n,e){"use strict";e.r(n);var u=e("c0cf"),r=e("11db");for(var f in r)"default"!==f&&function(t){e.d(n,t,function(){return r[t]})}(f);e("0f26");var o=e("2877"),a=Object(o["a"])(r["default"],u["a"],u["b"],!1,null,"015b2d49",null);n["default"]=a.exports},fbfa:function(t,n,e){}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/book/components/app-store-create-component',
    {
        'plugins/book/components/app-store-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("f09e"))
        })
    },
    [['plugins/book/components/app-store-create-component']]
]);                
