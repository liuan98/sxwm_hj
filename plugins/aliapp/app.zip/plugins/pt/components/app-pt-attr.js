;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/pt/components/app-pt-attr"],{"27cd":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"app-pt-attr",props:{pintuan_groups:{type:Array,default:function(){return[]}},selectGroupAttrId:String},data:function(){return{}},methods:{active:function(t){this.$emit("click",t)}}};n.default=u},3556:function(t,n,e){"use strict";e.r(n);var u=e("8bec"),r=e("6569");for(var c in r)"default"!==c&&function(t){e.d(n,t,function(){return r[t]})}(c);e("d438");var a=e("2877"),i=Object(a["a"])(r["default"],u["a"],u["b"],!1,null,"7ab2b2c7",null);n["default"]=i.exports},6569:function(t,n,e){"use strict";e.r(n);var u=e("27cd"),r=e.n(u);for(var c in u)"default"!==c&&function(t){e.d(n,t,function(){return u[t]})}(c);n["default"]=r.a},"8bec":function(t,n,e){"use strict";var u=function(){var t=this,n=t.$createElement;t._self._c},r=[];e.d(n,"a",function(){return u}),e.d(n,"b",function(){return r})},c970:function(t,n,e){},d438:function(t,n,e){"use strict";var u=e("c970"),r=e.n(u);r.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/pt/components/app-pt-attr-create-component',
    {
        'plugins/pt/components/app-pt-attr-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("3556"))
        })
    },
    [['plugins/pt/components/app-pt-attr-create-component']]
]);                
