(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/gift/components/receive/gift-over"],{"3b33":function(n,e,t){"use strict";var r=t("e1a7"),u=t.n(r);u.a},"499a":function(n,e,t){"use strict";var r=function(){var n=this,e=n.$createElement;n._self._c;n._isMounted||(n.e0=function(e){n.len=n.winUser.length})},u=[];t.d(e,"a",function(){return r}),t.d(e,"b",function(){return u})},5482:function(n,e,t){"use strict";t.r(e);var r=t("499a"),u=t("5d4e");for(var i in u)"default"!==i&&function(n){t.d(e,n,function(){return u[n]})}(i);t("3b33");var a=t("2877"),o=Object(a["a"])(u["default"],r["a"],r["b"],!1,null,"3934b807",null);e["default"]=o.exports},"5d4e":function(n,e,t){"use strict";t.r(e);var r=t("b3dd"),u=t.n(r);for(var i in r)"default"!==i&&function(n){t.d(e,n,function(){return r[n]})}(i);e["default"]=u.a},b3dd:function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={name:"gift-over",props:["num","winUser","open_type","type","userOrder","is_status","win_time"],data:function(){return{len:3}},computed:{newWinUser:function(){return this.winUser.slice(0,this.len)}}};e.default=r},e1a7:function(n,e,t){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/gift/components/receive/gift-over-create-component',
    {
        'plugins/gift/components/receive/gift-over-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("5482"))
        })
    },
    [['plugins/gift/components/receive/gift-over-create-component']]
]);                
